# Handoff: Outlet Manager — Mobile Redesign

## Overview
Full UI/UX redesign of the Outlet Manager field-sales/merchandising app, moving away from the old red/sharp "Modernist" look toward a Qonto-inspired premium mobile feel: soft off-white canvas, white rounded cards, black primary actions, a restrained purple accent, and a floating pill bottom nav. This is a **prototype-only** phase — no production Flutter code was changed.

## About the Design Files
`design_reference.html` is an **HTML design reference** (built as a Design Component prototype), not production code. It renders each screen inside an iPhone-style device frame purely for presentation. **Do not copy the HTML/inline-styles directly into the Flutter app.** Recreate each screen natively in Flutter using the existing app's widget patterns, theme, and state management (Riverpod, per the codebase), using this file as the visual and structural spec.

## Fidelity
**High-fidelity.** Colors, spacing, radii, type sizes, and copy shown are final intent — replicate pixel-close in Flutter, adapting only where Flutter/Material conventions require it.

## Design Tokens

Colors:
- Canvas: `#F5F5F3` (screen background)
- Surface: `#FFFFFF` (cards)
- Primary text: `#111111`
- Secondary text: `#6F6F6B`
- Tertiary text: `#9A9A96`
- Border: `#E7E7E3`
- Purple accent: `#4B2E83`
- Soft purple (tint): `#F1E6FF`
- Warm accent (tint): `#FFEAC9` / text `#8a5a00`
- Success tint: `#E6F4EA` / text `#1e6b2c`
- Danger: `#D50000` / tint `#FEE9E7`
- Dark hero header (used on task/detail screens): `#111111` with white/`rgba(255,255,255,.55-.65)` text

Typography: **Inter**, weights 400/500/600/700/800.
- Page title: 20px/800
- KPI value: 20–36px/800
- Section title: 14–15px/700
- Card title/body: 13–14px/600-700
- Secondary/meta: 11–12px/400-600
- Caption/uppercase labels: 9–11px, letter-spacing .05-.08em

Spacing scale: 4, 8, 10, 12, 14, 16, 18, 20, 24, 32px. Screen horizontal padding is consistently 20px.

Radii: cards 16–22px, buttons/chips/steppers fully pill (999px), small icon containers 10–14px or circular.

Navigation: floating white pill bottom nav (Home / Route / Tasks / Menu), ~16px side margins, soft shadow, selected item gets a soft-purple rounded background + purple icon/label.

## Screen inventory (grouped, matches file's lettered sections A–K)

**A. Design system** — token reference sheet (colors, type, spacing, components).

**B. Authentication** — Login (rounded inputs, black pill CTA, purple links), Location Permission (icon + explain + Enable/Not now).

**C. Home** — No-active-visit state (Today's Route card, Quick Actions grid, Performance KPIs, Recent Activity) and Active-visit state (dark "Active Visit" card promoted to top with progress + Continue Visit).

**D. Route & visits** — Today's Route (route summary, Next Outlet dark card, upcoming list), Outlet/Visit Detail (location validation banner + Clock In), Active Visit (duration hero, activity checklist, Clock Out).

**E. Merchandising** —
- *Stock Take*: session-based flow — Home/Dashboard (active + paused sessions per warehouse), Warehouse Selection, session-conflict dialog, Session Active (dark hero w/ live stats, min/max range-bar item cards, states: Completed/In Progress/Not Started), Add Product (brand-restricted search+scan), Serial Scanner (live camera frame, valid/duplicate/invalid validation rows), Complete Session confirm, Order Generation progress, Proposed Order (to-max/to-min toggle), Session History.
- *Daily Sales*: this module is actually a **per-outlet daily summary/report**, not a product cart — Select Outlet, then an editable Outlet Summary (outlet details/OCM-KAC, reporting times, stock-take start/end, tentative/stock-based/confirmed sales, warranties + shelf-share/facings status, Sales MTD & Stocks Value MTD Exc/Inc VAT, aftersales qty) with tap-to-edit fields.
- *Shelf Share*: Home (Active/Completed/All Items tabs), Session screen (item groups w/ brand share-bar previews, Add Item Group / Submit / End Session), Item Group Selection, Brand Entry (Selected tab w/ live % share + qty stepper, Add Brands tab).
- *Facings Count*: Home (Active/Today's Counts tabs), Cart screen (item groups w/ plain qty stepper — no brand/share, per real data model), Item Group Selection.

**F. Sales (Orders & Quotations)** — Orders Home (dark stats hero: open value/awaiting action/fulfilled, Orders/Quotations toggle, status-icon cards), Quotations tab (Convert to Order action), New-type sheet (Order vs Quotation), Select Customer (credit-line balance shown on credit customers, cash-customer-forces-quotation warning), Create Order (per-line discount, running total), Submit Details sheet (warehouse/LPO/notes), Order Detail (3-step status tracker: Placed→Confirm→Fulfil).
  - Separately: Register Sale is a **3-step stepper** (Products → Customer → Review/Summary) with per-item incentive-earned shown on both the cart and Sale Detail; a Replenishment screen (suggested reorder from confirmed sales, severity tiers, checkbox select) feeds a "Convert to Sales Order" sheet requiring an LPO number.

**G. Products** — Products list (brand/category filters), Product Detail with tabs (Overview incl. warehouse stock + stock-ageing donut, Insights, Alternatives, Competitors w/ per-outlet competitor pricing).

**G2. After Sales** — List (status chips: Open/Resolved), Register Complaint, Detail screen (status + receive-status, customer/product/reported-fault, conditional Warehouse Tracking, Receive/Release-to-Customer actions + confirm sheet).

**H. My Performance** — Summary/Sellout/Sales Target tabs, all **currency-based** (not units): achievement ring, target vs sold, gap-to-target, pace-to-target card (run-rate vs needed rate), 6-month trend bars, category contribution breakdown, projected-outcome card; outlet + month/year filters; no-target and select-outlet-required empty states.

**I. Tasks** — Due Today / In Progress / Completed sections.

**J. Menu & Activity** — Profile menu (Sales & Merchandising / Tools / Activity / Account groups), Session History.

**K. System states** — Loading (skeleton shimmer), Empty, Offline/Error/Success patterns.

## Interactions & Behavior
- Steppers (`− qty +`) are the universal quantity control across Stock Take, Facings, Shelf Share, Orders — pill-shaped, ≥30px touch targets.
- Status is always communicated via **icon + color + text**, never color alone.
- Bottom sheets (rounded top corners, drag handle) are used for confirmations, filters, and multi-field quick entry — not center modals.
- Dark (`#111`) hero headers are used specifically on **active/in-progress task screens** (Session Active, Add Product, Serial Scanner, Sale Detail, Order Detail, Replenishment, Confirm Sale, Daily Sales Home, Orders Home) to visually distinguish "in a task" from browsing screens (which use the light canvas header).
- Credit customers show an available/limit credit-line bar on Select Customer; near-exhausted lines get a red warning treatment.

## State Management
Follow the existing Flutter app's patterns (Riverpod controllers per feature, as already used for `shelf_share`, `facings_count`, `stock_take` in the codebase). No new state architecture was introduced — this phase only redesigns the presentation layer.

## Assets
No custom image assets — all icons are inline Lucide-style SVGs (stroke-based, 1.75px weight). Product/photo placeholders use a diagonal-stripe pattern; replace with real product imagery in production.

## Files
- `design_reference.html` — the full multi-screen design reference (open in a browser; each screen is presented inside a phone frame, grouped and labelled A–K as above).
